<p><img src="https://raw.githubusercontent.com/agragregra/Simple-Starter/main/images/preview.png" alt="Start HTML Template"></p>
<p>Clone:</p>
<pre>git clone https://github.com/agragregra/Simple-Starter .; rm -rf trunk .gitignore readme.md .git</pre>